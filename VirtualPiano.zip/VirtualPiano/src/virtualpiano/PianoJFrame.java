/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package virtualpiano;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.audio.AudioData;
import sun.audio.AudioDataStream;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;
import sun.audio.ContinuousAudioDataStream;
        
public class PianoJFrame extends javax.swing.JFrame {

    AudioPlayer MGP = AudioPlayer.player;
    AudioStream BGM;
    AudioData MD;
    AudioDataStream loop = null;
     
    public PianoJFrame() {
        initComponents();
        setSize(700,380);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        CHButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jchkMusic = new javax.swing.JRadioButton();
        DHButton = new javax.swing.JButton();
        DButton = new javax.swing.JButton();
        E = new javax.swing.JButton();
        FHButton = new javax.swing.JButton();
        FButton = new javax.swing.JButton();
        GHBotton = new javax.swing.JButton();
        GButton = new javax.swing.JButton();
        BbButton = new javax.swing.JButton();
        AButton = new javax.swing.JButton();
        BButton = new javax.swing.JButton();
        HHButton = new javax.swing.JButton();
        C1Button = new javax.swing.JButton();
        IHButton = new javax.swing.JButton();
        D1Button = new javax.swing.JButton();
        E1Button = new javax.swing.JButton();
        F1 = new javax.swing.JButton();
        CButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBackground(java.awt.Color.black);
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 8));
        jPanel1.setLayout(null);

        CHButton.setBackground(new java.awt.Color(0, 0, 0));
        CHButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        CHButton.setForeground(new java.awt.Color(255, 255, 255));
        CHButton.setText("C#"); // NOI18N
        CHButton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        CHButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CHButtonActionPerformed(evt);
            }
        });
        jPanel1.add(CHButton);
        CHButton.setBounds(50, 80, 55, 110);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("virtual Piano");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(260, 10, 140, 30);

        buttonGroup1.add(jCheckBox1);
        jCheckBox1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jCheckBox1.setText("Music Notes");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });
        jPanel1.add(jCheckBox1);
        jCheckBox1.setBounds(100, 40, 110, 23);

        buttonGroup1.add(jchkMusic);
        jchkMusic.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jchkMusic.setText("Virtual Steel Drum");
        jPanel1.add(jchkMusic);
        jchkMusic.setBounds(450, 40, 150, 25);

        DHButton.setBackground(java.awt.Color.black);
        DHButton.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        DHButton.setForeground(new java.awt.Color(255, 255, 255));
        DHButton.setText("D#");
        DHButton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        DHButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DHButtonActionPerformed(evt);
            }
        });
        jPanel1.add(DHButton);
        DHButton.setBounds(108, 80, 55, 110);

        DButton.setBackground(new java.awt.Color(255, 255, 255));
        DButton.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        DButton.setText("D");
        DButton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        DButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DButtonActionPerformed(evt);
            }
        });
        jPanel1.add(DButton);
        DButton.setBounds(92, 80, 50, 230);

        E.setText("E");
        E.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        E.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EActionPerformed(evt);
            }
        });
        jPanel1.add(E);
        E.setBounds(144, 80, 50, 230);

        FHButton.setBackground(new java.awt.Color(0, 0, 0));
        FHButton.setForeground(new java.awt.Color(255, 255, 255));
        FHButton.setText("F#");
        FHButton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        FHButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FHButtonActionPerformed(evt);
            }
        });
        jPanel1.add(FHButton);
        FHButton.setBounds(212, 80, 55, 110);

        FButton.setText("F");
        FButton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        FButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FButtonActionPerformed(evt);
            }
        });
        jPanel1.add(FButton);
        FButton.setBounds(196, 80, 50, 230);

        GHBotton.setBackground(new java.awt.Color(0, 0, 0));
        GHBotton.setForeground(new java.awt.Color(255, 255, 255));
        GHBotton.setText("G#");
        GHBotton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        GHBotton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GHBottonActionPerformed(evt);
            }
        });
        jPanel1.add(GHBotton);
        GHBotton.setBounds(270, 80, 55, 110);

        GButton.setText("G");
        GButton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        GButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GButtonActionPerformed(evt);
            }
        });
        jPanel1.add(GButton);
        GButton.setBounds(248, 80, 50, 230);

        BbButton.setBackground(new java.awt.Color(0, 0, 0));
        BbButton.setForeground(new java.awt.Color(255, 255, 255));
        BbButton.setText("Bb");
        BbButton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        BbButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BbButtonActionPerformed(evt);
            }
        });
        jPanel1.add(BbButton);
        BbButton.setBounds(328, 80, 55, 110);

        AButton.setText("A");
        AButton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        AButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AButtonActionPerformed(evt);
            }
        });
        jPanel1.add(AButton);
        AButton.setBounds(300, 80, 50, 230);

        BButton.setText("B");
        BButton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        BButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BButtonActionPerformed(evt);
            }
        });
        jPanel1.add(BButton);
        BButton.setBounds(352, 80, 50, 230);

        HHButton.setBackground(new java.awt.Color(0, 0, 0));
        HHButton.setForeground(new java.awt.Color(255, 255, 255));
        HHButton.setText("C#1");
        HHButton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        HHButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HHButtonActionPerformed(evt);
            }
        });
        jPanel1.add(HHButton);
        HHButton.setBounds(418, 80, 55, 110);

        C1Button.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        C1Button.setText("C1");
        C1Button.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        C1Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                C1ButtonActionPerformed(evt);
            }
        });
        jPanel1.add(C1Button);
        C1Button.setBounds(404, 80, 50, 230);

        IHButton.setBackground(new java.awt.Color(0, 0, 0));
        IHButton.setForeground(new java.awt.Color(255, 255, 255));
        IHButton.setText("D#1");
        IHButton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        IHButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IHButtonActionPerformed(evt);
            }
        });
        jPanel1.add(IHButton);
        IHButton.setBounds(476, 80, 55, 110);

        D1Button.setText("D1");
        D1Button.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        D1Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                D1ButtonActionPerformed(evt);
            }
        });
        jPanel1.add(D1Button);
        D1Button.setBounds(456, 80, 50, 230);

        E1Button.setText("E1");
        E1Button.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        E1Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                E1ButtonActionPerformed(evt);
            }
        });
        jPanel1.add(E1Button);
        E1Button.setBounds(508, 80, 50, 230);

        F1.setText("F1");
        F1.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        F1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                F1ActionPerformed(evt);
            }
        });
        jPanel1.add(F1);
        F1.setBounds(560, 80, 50, 230);

        CButton.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        CButton.setText("C");
        CButton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        CButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CButtonActionPerformed(evt);
            }
        });
        jPanel1.add(CButton);
        CButton.setBounds(40, 80, 50, 230);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 680, 330);

        pack();
    }// </editor-fold>//GEN-END:initComponents
/*
    private void AButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AButtonActionPerformed
           try {
            
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("A_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("A.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        // TODO add your handling code here:
    }//GEN-LAST:event_AButtonActionPerformed

    private void CHButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CHButtonActionPerformed
        try{
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("Cq_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("C_s.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        
    }//GEN-LAST:event_CHButtonActionPerformed

    private void EActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EActionPerformed
        try {
            
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("E_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("E.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        
    }//GEN-LAST:event_EActionPerformed

    private void DHButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DHButtonActionPerformed
        try {
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("D1_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("D_s.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        // TODO add your handling code here:
    }//GEN-LAST:event_DHButtonActionPerformed

    private void DButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DButtonActionPerformed
            try {
                
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("D_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("D.wav")); 
        }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        
    }//GEN-LAST:event_DButtonActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
       
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void FButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FButtonActionPerformed
        try {

            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("F_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("F.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        
    }//GEN-LAST:event_FButtonActionPerformed

    private void FHButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FHButtonActionPerformed
       try {
            
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("Fq_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("F_s.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop); // TODO add your handling code here:
    }//GEN-LAST:event_FHButtonActionPerformed

    private void GButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GButtonActionPerformed
           try {
            
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("G_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("G.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        
    }//GEN-LAST:event_GButtonActionPerformed

    private void GHBottonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GHBottonActionPerformed
        try {
            
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("Gq_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("G_s.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        
    }//GEN-LAST:event_GHBottonActionPerformed

    private void BbButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BbButtonActionPerformed
        try {
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("Bb_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("Bb.wav")); 
            }
            
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        // TODO add your handling code here:
    }//GEN-LAST:event_BbButtonActionPerformed

    private void BButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BButtonActionPerformed
        try {
           
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("B_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("B.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        
    }//GEN-LAST:event_BButtonActionPerformed

    private void C1ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_C1ButtonActionPerformed
           try {
            
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("C1_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("C1.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        
    }//GEN-LAST:event_C1ButtonActionPerformed

    private void HHButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HHButtonActionPerformed
           try {
               
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("Cq1_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("C_s1.wav")); 
            }
            
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        // TODO add your handling code here:
    }//GEN-LAST:event_HHButtonActionPerformed

    private void D1ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_D1ButtonActionPerformed
            try {
            
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("D1_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("D1.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        
    }//GEN-LAST:event_D1ButtonActionPerformed

    private void IHButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IHButtonActionPerformed
        try {
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("Dq1_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("D_s1.wav")); 
            }
            
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        
    }//GEN-LAST:event_IHButtonActionPerformed

    private void E1ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_E1ButtonActionPerformed
        try {
           
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("E1_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("E1.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        
    }//GEN-LAST:event_E1ButtonActionPerformed

    private void F1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_F1ActionPerformed
            try {
            
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("F1_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("F1.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);        
    }//GEN-LAST:event_F1ActionPerformed

    private void CButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CButtonActionPerformed

        try {
            if(jchkMusic.isSelected()){
                BGM = new AudioStream(new FileInputStream("C_Drum.wav"));
            }
            else{
                BGM = new AudioStream(new FileInputStream("C.wav")); 
            }
            MD = BGM.getData();
            loop = new AudioDataStream(MD);
        } 
        catch (IOException ex) {
            Logger.getLogger(VP.class.getName()).log(Level.SEVERE, null, ex);
        }
        MGP.start(loop);       
                             
    }//GEN-LAST:event_CButtonActionPerformed
     */
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PianoJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AButton;
    private javax.swing.JButton BButton;
    private javax.swing.JButton BbButton;
    private javax.swing.JButton C1Button;
    private javax.swing.JButton CButton;
    private javax.swing.JButton CHButton;
    private javax.swing.JButton D1Button;
    private javax.swing.JButton DButton;
    private javax.swing.JButton DHButton;
    private javax.swing.JButton E;
    private javax.swing.JButton E1Button;
    private javax.swing.JButton F1;
    private javax.swing.JButton FButton;
    private javax.swing.JButton FHButton;
    private javax.swing.JButton GButton;
    private javax.swing.JButton GHBotton;
    private javax.swing.JButton HHButton;
    private javax.swing.JButton IHButton;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jchkMusic;
    // End of variables declaration//GEN-END:variables
}
